<?php

function Load($content = '') {
	global $tt;
	
    $page         = $content . '.phtml';
    $page_content = '';
	
    ob_start();
    require($page);
    $page_content = ob_get_contents();
    ob_end_clean();
	
    return $page_content;
}

function Search($search) {
	global $connect;
	
	$select = mysqli_query($connect, "SELECT * FROM users WHERE ((`nome` LIKE '%$search%') OR ( `email` LIKE '%$search%')) ORDER BY `id` DESC LIMIT 10");
	
	if(mysqli_num_rows($select) > 0) {
		while($assoc = mysqli_fetch_assoc($select)) {
			$data[] = $assoc;
		}
		return $data;
	} else {
		return false;
	}
}
?>