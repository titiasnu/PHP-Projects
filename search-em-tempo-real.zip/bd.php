<?php
	$host = "localhost";
	$bd = "tutoriais";
	$user = "root";
	$pass = "";
	$connect = mysqli_connect($host, $user, $pass, $bd);
?>