<?php
function CountMessages($user_id) {
	global $connect;

	$select =	mysqli_query($connect, "SELECT * FROM messages WHERE `from_id` = '{$user_id}' AND `to_id` = '{$_COOKIE['user_id']}' AND `seen` = '0' ORDER BY `id`");
	if(mysqli_num_rows($select) > 0) {
		return mysqli_num_rows($select);
	} else {
		return false;
	}
}

function Time_Elapsed_String($ptime) {
    
    $etime = time() - $ptime;
    if ($etime < 1) {
        return '0 seconds';
    }
	
	$tt['lang'] = array(
        'year' => 'ano',
        'month' => 'mes',
        'day' => 'dia',
        'hour' => 'hora',
        'minute' => 'minuto',
        'second' => 'segundo'
    );
	
    $a        = array(
        365 * 24 * 60 * 60 => $tt['lang']['year'],
        30 * 24 * 60 * 60 => $tt['lang']['month'],
        24 * 60 * 60 => $tt['lang']['day'],
        60 * 60 => $tt['lang']['hour'],
        60 => $tt['lang']['minute'],
        1 => $tt['lang']['second']
    );
    $a_plural = array(
        $tt['lang']['year'] => 'anos',
        $tt['lang']['month'] => 'meses',
        $tt['lang']['day'] => 'dias',
        $tt['lang']['hour'] => 'horaas',
        $tt['lang']['minute'] => 'minutos',
        $tt['lang']['second'] => 'segundos'
    );
    foreach ($a as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);

                $time_ago = $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ' . 'atrás';
            
            return $time_ago;
        }
    }
}

function SeenMessages($user_id) {
	global $connect;
	
	$update = mysqli_query($connect, "UPDATE messages SET `seen` = '" . time() . "' WHERE `from_id` = '{$user_id}' AND `to_id` = '{$_COOKIE['user_id']}' AND `seen` = '0' ");
	if($update) {
		return true;
	} else {
		return false;
	}
}

function getMessagesUser($user_id) {
	global $connect;

	$select =	mysqli_query($connect, "SELECT * FROM messages WHERE `from_id` = '{$user_id}' AND `to_id` = '{$_COOKIE['user_id']}' AND `seen` = '0' ORDER BY `id`");
	if(mysqli_num_rows($select) > 0) {
		return true;
	} else {
		return false;
	}
}
function GetMessageDataChat($from_id, $to_id) {
	global $connect;

	$select =	mysqli_query($connect, "SELECT * FROM messages WHERE `from_id` = '{$from_id}' AND `to_id` = '{$to_id}' OR `from_id` = '{$to_id}' AND `to_id` = '{$from_id}' ORDER BY `id` ASC LIMIT 25");
	if(mysqli_num_rows($select) > 0) {
		while($assoc = mysqli_fetch_assoc($select)) {
			$data[] = $assoc;
		}
		return $data;
	} else {
		return 0;
	}
}

function sendMessage($re_data = array()) {
	global $connect;
	
	$fields  = '`' . implode('`, `', array_keys($re_data)) . '`';
    $data    = '\'' . implode('\', \'', $re_data) . '\'';
	
	$insert	=	mysqli_query($connect, "INSERT INTO messages({$fields}) VALUES ({$data})");
	
	if($insert) {
		return true;
	} else {
		return false;
	}
}

function carregarPagina($content = '') {
	global $tt;
	
    $page         = $content . '.phtml';
    $page_content = '';
	
    ob_start();
    require($page);
    $page_content = ob_get_contents();
    ob_end_clean();
	
    return $page_content;
}
function GetUserDataChat($user_id) {
	global $connect;

	$select =	mysqli_query($connect, "SELECT * FROM users WHERE `id` = '{$user_id}'");
	if(mysqli_num_rows($select) > 0) {
		while($assoc = mysqli_fetch_assoc($select)) {
			$data[] = $assoc;
		}
		
		return $data;
	} else {
		return false;
	}
}
function GetUsers() {
	global $connect;
	
	$select =	mysqli_query($connect, "SELECT * FROM users WHERE `id` != '{$_COOKIE['user_id']}' ORDER BY `id` DESC");
	while($assoc = mysqli_fetch_assoc($select)) {
		$data[] = $assoc;
	}
	
	return $data;
}
function login($data = array()) {
	global $connect;
	
	$email = $data['email'];
	$senha = $data['password'];
	
	$select =	mysqli_query($connect, "SELECT `id` FROM users WHERE `email` = '{$email}' AND `password` = '{$senha}'");
	
	if(mysqli_num_rows($select) > 0) {
		$assoc = mysqli_fetch_assoc($select);
		return $assoc['id'];
	
	} else {
		return false;
	}
	
	
}

function cadastrar($re_data = array()) {
	global $connect;
	
	$fields  = '`' . implode('`, `', array_keys($re_data)) . '`';
    $data    = '\'' . implode('\', \'', $re_data) . '\'';
	
	$insert	=	mysqli_query($connect, "INSERT INTO users({$fields}) VALUES ({$data})");
	
	if($insert) {
		$sql = mysqli_insert_id($connect);
		
		return $sql;
		
	} else {
		return false;
	}
}

?>