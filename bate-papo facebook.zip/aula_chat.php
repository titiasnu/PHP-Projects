<?php
include_once 'bd.php';
session_start();

include_once 'functions_aula.php';

if(!empty($_GET['f'])) {
	$f = $_GET['f'];
} else {
	$f = '';
}

if(!empty($_GET['s'])) {
	$s = $_GET['s'];
} else {
	$s = '';
}

if($f == 'chat') {
	
	if($s == 'count_messages') {
		$user_id = mysqli_real_escape_string($connect, $_GET['user_id']);
			
		if(CountMessages($user_id)) {
			
			$data = array(
				'status' => 200,
				'number' => CountMessages($user_id)
			);
			
		} else {
			$data = array(
				'status' => 400
			);
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();
	}
	
	if($s == 'seen') {
		
		if($_GET['user_id'] == $_SESSION['chat_id']) {
			$user_id = mysqli_real_escape_string($connect, $_GET['user_id']);
			
			if(SeenMessages($user_id)) {
				
				$data = array(
					'status' => 200
				);
				
			} else {
				$data = array(
					'status' => 400
				);
			}
			
		} else {
			$data = array(
				'status' => 400
			);
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();
	}

	if($s == 'get_messages_user') {
		
		if($_GET['user_id'] == $_SESSION['chat_id']) {
			$user_id = mysqli_real_escape_string($connect, $_GET['user_id']);
			
			if(getMessagesUser($user_id)) {
				
				$data = array(
					'status' => 200,
					'id' => $user_id
				);
				
			} else {
				$data = array(
					'status' => 400,
					'id' => $user_id
				);
			}
			
		} else {
			$data = array(
				'status' => 400
			);
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();
	}

	if($s == 'get_message') {
		$chat_id = mysqli_real_escape_string($connect, $_GET['user_id']);
		
		if($chat_id == $_COOKIE['user_id']) {
				
			$data = array(
				'status' => 400
			);
			
		} else {
			if($_SESSION['chat_id'] = $chat_id) {
					
					$html = '';
					
					$html_fi = GetMessageDataChat($_COOKIE['user_id'], $chat_id);
					
					if(count($html_fi) > 0) {
						foreach($html_fi as $tt['chat_text']) {
							$html	.=	carregarPagina('chat-text');
						}
						
						$data = array(
							'status' => 200,
							'message' => $html
						);
					} else {
						$data = array(
							'status' => 400
						);
					}
				
			} else {
				
				$data = array(
					'status' => 400
				);
				
			}
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();
	}
	
	if($s == 'send_message') {
		$chat_id = mysqli_real_escape_string($connect, $_POST['user_id']);
		
		if($chat_id == $_COOKIE['user_id']) {
				
			$data = array(
				'status' => 400
			);
			
		} else {
			if($_SESSION['chat_id'] = $chat_id) {
				
				$message_text = mysqli_real_escape_string($connect, $_POST['send_text_chat']);
				
				$message = array(
					'from_id' => $_COOKIE['user_id'],
					'to_id' => $chat_id,
					'message_text' => $message_text
				);
				
				if(sendMessage($message)) {
					
					$data = array(
						'status' => 200
					);
					
				} else {
					$data = array(
						'status' => 400
					);
				}
				
			} else {
				
				$data = array(
					'status' => 400
				);
				
			}
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();

	}
	
	if($s == 'min_chat') {
		$chat_id = mysqli_real_escape_string($connect, $_GET['user_id']);
		
		if($chat_id == $_COOKIE['user_id']) {
				
			$data = array(
				'status' => 400
			);
			
		} else {
			if($_SESSION['chat_id'] = $chat_id) {
				
				if(isset($_SESSION['min'])) {
					
					session_destroy();
					unset($_SESSION['min']);
				
				} else if(!isset($_SESSION['min'])) {

					$_SESSION['min'] = '1';
				}
				$data = array(
					'status' => 200
				);
				
			} else {
				$data = array(
					'status' => 400
				);
			}
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();

	}
	
	if($s == 'close_chat') {
		$chat_id = mysqli_real_escape_string($connect, $_GET['user_id']);
		
		if($chat_id == $_COOKIE['user_id']) {
				
			$data = array(
				'status' => 400
			);
			
		} else {
			if($_SESSION['chat_id'] = $chat_id) {
				
				session_destroy();
				
				unset($_SESSION['chat_id']);
				
				$data = array(
					'status' => 200
				);
				
			} else {
				$data = array(
					'status' => 400
				);
			}
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();

	}
	
	if($s == 'open_chat') {
		
		if(!empty($_GET['user_id'])) {
			$chat_id = mysqli_real_escape_string($connect, $_GET['user_id']);
			
			if($chat_id == $_COOKIE['user_id']) {
				
				$data = array(
					'status' => 400
				);
				
			} else {
				if($_SESSION['chat_id'] = $chat_id) {
					
					$html = '';
					
					$html_fi = GetUserDataChat($chat_id);
					
					if(count($html_fi) > 0) {
						foreach($html_fi as $tt['chat']) {
							$html	.=	carregarPagina('chat');
						}
						
						session_destroy();
						unset($_SESSION['min']);
						
						$data = array(
							'status' => 200,
							'message' => $html
						);
					} else {
						$data = array(
							'status' => 400
						);
					}
				} else {
					$data = array(
						'status' => 400
					);
				}
			}
			
		} else {
			$data = array(
				'status' => 400
			);
		}
		
		header("Content-type: application/json");
		echo json_encode($data);
		exit();
	}
}

if($f == 'login') {
	if(!empty($_POST['email']) && !empty($_POST['senha'])) {
		$email = mysqli_real_escape_string($connect, $_POST['email']);
		$senha = mysqli_real_escape_string($connect, md5($_POST['senha']));
		
		$html = array(
			'email' => $email,
			'password' => $senha
		);
		
		$retorno = login($html);
		
		if($retorno) {
			$data = array(
				'status' => 200
			);
			
			$_SESSION['user_id'] = $retorno;
			
			setcookie(
				'user_id', $retorno, time() + (24 * 7 * 30 * 360)
			);
			
		} else {
			$data = array(
				'status' => 400
			);
		}
	
	} else {
		$data = array(
			'status' => 400
		);
	}
	
	header("Content-type: application/json");
	echo json_encode($data);
	exit();
}

if($f == 'register') {
	if(!empty($_POST['email']) && !empty($_POST['senha']) && !empty($_POST['nome'])) {
		$email = mysqli_real_escape_string($connect, $_POST['email']);
		$senha = mysqli_real_escape_string($connect, md5($_POST['senha']));
		$nome = mysqli_real_escape_string($connect, $_POST['nome']);
		
		$html = array(
			'email' => $email,
			'password' => $senha,
			'nome' => $nome
		);
		
		$retorno = cadastrar($html);
		
		if($retorno) {
			$data = array(
				'status' => 200
			);
			
			$_SESSION['user_id'] = $retorno;
			
			setcookie(
				'user_id', $retorno, time() + (24 * 7 * 30 * 360)
			);
			
		} else {
			$data = array(
				'status' => 400
			);
		}
	} else {
		$data = array(
			'status' => 400
		);
	}
	
	header("Content-type: application/json");
	echo json_encode($data);
	exit();
	
}
	
mysqli_close($connect);
?>