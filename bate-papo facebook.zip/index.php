<?php
	error_reporting(0);
	include_once('bd.php');
	
	session_start();
	include_once('functions_aula.php');
	
?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Bate-papo</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.1/jquery.form.min.js" integrity="sha384-tIwI8+qJdZBtYYCKwRkjxBGQVZS3gGozr3CtI+5JF/oL1JmPEHzCEnIKbDbLTCer" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<style>
		.user-chat a {
			text-decoration:none;
		}
		.pointer {
			cursor: pointer;
		}
		.container-chat {
			width: 230px;
			height: 100%;
			overflow-y: auto;
			background-color: #ffffff;
			padding: 5px;
			border-left: solid 1px #cecece;
			position: fixed;
			right: 0;
		}
		.user-chat {
			width: 100%;
			min-height: 52px;
			border-bottom: solid 1px #cecece;
			margin-bottom: 3px;
			padding: 3px;
			word-break: break-word;
		}
		.user-chat img {
			width: 40px;
			height: 40px;
		}
		.chat .container-messages {
			width: 100%;
			height: 288px;
			background-color: #fff;
			bottom: 0;
		}
		.chat {
			width: 250px;
			max-height: 320px;
			bottom: 0;
			border: solid 1px #cecece;
			border-top-left-radius: 2px;
			border-top-right-radius: 2px;
			background-color: #ffffff;
			position: fixed;
			right: 18%;
		}
		.chat .topo {
			height: 32px;
			background-color: #5179ff;
			padding: 3px;
			padding-top: 0;
			font-size: 15px;
			font-weight: bold;
			color: #fff;
		}
		.chat .topo span {
			font-size: 22px;
			color: #fff;
			padding: 5px;
			z-index: 1;
		}
		.send-text-chat {
			bottom: 0;
		}
		#textarea-chat {
			width: 100%;
			border: none;
			border-top: solid 1px #cecece;
			padding: 7px;
			max-height: 35px;
		}
		.container-messages .list-messages-text {
			width: 100%;
			height: 248px;
			max-height: 248px;
			word-break: break-word;
			padding: 5px;
			overflow-y: auto;
		}
		textarea:focus {
			box-shadow: 0 0 0 0;
			border: 0 none;
			outline: 0;
		}
		textarea {
			resize: none;
		}
		.float-left {
			float: left;
		}
		.float-right {
			float: right;
		}
		.message-left {
			width: 122.5px;
			background-color: #fff;
			border: solid 1px #ececec;
			border-top-right-radius: 7px;
			border-bottom-right-radius: 7px;
			border-bottom-left-radius: 7px;
			color: #868686;
			padding: 5px;
			margin-bottom: 5px;
		}
		.message-right {
			width: 122.5px;
			background-color: #5179ff;
			border: solid 1px #ececec;
			border-top-left-radius: 7px;
			border-bottom-right-radius: 7px;
			border-bottom-left-radius: 7px;
			color: #fff;
			padding: 5px;
			margin-bottom: 5px;
		}
	</style>
	<script type="text/javascript">
	<?php 
		if(isset($_SESSION['chat_id'])) {
	?>
		$(function () {
			setTimeout(function() {
				AbrirChat(<?php echo $_SESSION['chat_id']; ?>);
			}, 100);
		});
	<?php } ?>
		$(function () {
			setTimeout(function() {
				GetMessagesUser(<?php echo $_SESSION['chat_id']; ?>);
			}, 2000);
		});
		
		function GetMessagesUser(id) {
			$.get('aula_chat.php?f=chat&s=get_messages_user&user_id=' + id, {
				
			}, function (data) {
				if(data.status == 200) {
					GetMessages(data.id);
				}
				setTimeout(function () {
					GetMessagesUser(data.id);
				}, 5000);
			});
		}
		
		function SubmitSeen(user_id) {
			$.get('aula_chat.php?f=chat&s=seen&user_id=' + user_id, {
				
			}, function (data) {
				if(data.staus == 200) {
					return true;
				} else {
					return false;
				}
			});
		}
		
		function AbrirChat(user_id) {
			$.get('aula_chat.php?f=chat&s=open_chat&user_id=' + user_id, {
				
			}, function (data) {
				if(data.status == 200) {
					setTimeout( function () {
						$('.list-chat').html(data.message);
						GetMessages(user_id);
					}, 1000);
				} else {
					return false;
				}
			});
		}
		function GetMessages(user_id) {
			$.get('aula_chat.php?f=chat&s=get_message&user_id=' + user_id, {
				
			}, function (data) {
				if(data.status == 200) {
					$('.list-messages-text').html(data.message);
					setTimeout(function (){
						$('.container-messages .list-messages-text').scrollTop($('.container-messages .list-messages-text')[0].scrollHeight);
					}, 50);
				} else {
					return true;
				}
			});
		}
		function FecharChat(user_id) {
			$.get('aula_chat.php?f=chat&s=close_chat&user_id=' + user_id, {
				
			}, function (data) {
				if(data.status == 200) {
					$('.list-chat').html('');
				} else {
					return false;
				}
			});
		}
	</script>
</head>
<body style="background-color: #f9f9f9;">
	<div class="container">
		<div class="row">
			<?php
				if($_COOKIE['user_id'] == 0) {
			?>
			
			<?php
				if(!isset($_GET['pg'])) {
					
					include_once('login2.phtml');
					
				} else if ($_GET['pg'] == 'register') {
					
					include_once('register.phtml');
					
				} 
			?>
			
			<?php
				} else {
					include_once('bate-papo.phtml');
				}
			?>
		</div>
	</div>
	<footer>
		<div class="list-chat"></div>
</footer>
</body>
</html>
<?php
	mysqli_close($connect);
?>